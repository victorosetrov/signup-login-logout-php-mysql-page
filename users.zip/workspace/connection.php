<?php

    $link = mysqli_connect("localhost", "aliamusina", "n4SRy2J9ejUeKZEM", "c9");
       if (mysqli_connect_error()) {
            
            die ("Database Connection Error");
            
        }

?>